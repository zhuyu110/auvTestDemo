package com.auv.sienlockdemo;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.MainTotalCell)
    EditText MainTotalCell;

    @BindView(R.id.SecondTotalCellCount)
    EditText SecondCount;

    @BindView(R.id.SecondTotalCell)
    EditText SecondTotalCell;

    private String TAG="MainActivity";

    Boolean bOpen;

    @BindView(R.id.cellNumber)
    TextView cellNumber;

    int i;

    boolean isFinish;

    Boolean isOpenPort;

    @BindView(R.id.openAndClosePort)
    Button openAndClosePort;

    @BindView(R.id.serialPortName)
    TextView serialPortName;

    public MainActivity() {
        Boolean bool=Boolean.TRUE;
        this.isOpenPort=bool;
        this.bOpen=bool;
        this.i=0;
        this.isFinish=false;
    }

    private void modifyCellTotal() {
        if (this.MainTotalCell.getText().toString().isEmpty()) {
            showToast("主板柜位数不能为空");
            return;
        }
        if (this.SecondTotalCell.getText().toString().isEmpty()) {
            showToast("副板柜位数不能为空！");
            return;
        }
        if (this.SecondCount.getText().toString().isEmpty()) {
            showToast("副板板数不能为空！");
            return;
        }
        BaseApplication.strMainCellTotal=this.MainTotalCell.getText().toString();
        BaseApplication.strSecondaryCellTotal=this.SecondTotalCell.getText().toString();
        BaseApplication.getStrSecondaryCount=this.SecondCount.getText().toString();
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append("modifyCellTotal: ");
        stringBuilder.append(BaseApplication.strMainCellTotal);
        stringBuilder.append("\n");
        stringBuilder.append(BaseApplication.strSecondaryCellTotal);
        stringBuilder.append("\n");
        stringBuilder.append(BaseApplication.getStrSecondaryCount);
        Log.d("MainActivity", stringBuilder.toString());
        showToast("修改成功");
    }

    private void openAndClosePort() {
        BaseApplication.PORT_NAME=this.serialPortName.getText().toString();
        String stringBuilder=this.TAG +
                "PORT_NAME =";
        Log.d(stringBuilder, BaseApplication.PORT_NAME);
        if (this.isOpenPort) {
            this.isOpenPort=Boolean.FALSE;
            LockControlBoardUtils.getInstances().closeSerialPort();
            this.openAndClosePort.setText("打开串口");
            return;
        }
        this.isOpenPort=Boolean.TRUE;
        LockControlBoardUtils.getInstances().openSerialPort();
        this.openAndClosePort.setText("关闭串口");
    }

    private void openDoor() {
        if (this.bOpen) {
            this.bOpen=Boolean.FALSE;
            if (this.cellNumber.getText().toString().isEmpty()) {
               showToast("柜位号不能为空！");
                return;
            }
            LockControlBoardUtils.OpenCell(Integer.parseInt(this.cellNumber.getText().toString()), new LockControlBoardUtils.OpenDoorCallBack() {
                public void fail(String param1String) {
                    Log.d(MainActivity.this.TAG, "fail: ");
                    showToast(param1String);
                    MainActivity.this.bOpen=Boolean.TRUE;
                }

                public void success(boolean param1Boolean) {
                    Log.d(MainActivity.this.TAG, "success: ");
                    showToast(param1Boolean ? "打开成功" : "打开失败");
                    MainActivity.this.bOpen=Boolean.TRUE;
                }
            });
            int i=Integer.parseInt(this.cellNumber.getText().toString());
            TextView textView=this.cellNumber;
            String stringBuilder=(i + 1) +
                    "";
            textView.setText(stringBuilder);
        }
    }

    private void openDoorAll() {
        this.isFinish=false;
        LockControlBoardUtils.OpenCell(0, new LockControlBoardUtils.OpenDoorCallBack() {
            public void fail(String param1String) {
                Log.d(MainActivity.this.TAG, "fail: ");
                MainActivity.this.isFinish=true;
                showToast(param1String);
            }

            public void success(boolean param1Boolean) {
                Log.d(MainActivity.this.TAG, "success: ");
                showToast(param1Boolean ? "打开成功" : "打开失败");
            }
        });
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        this.serialPortName.setText(BaseApplication.PORT_NAME);
        this.MainTotalCell.setText(BaseApplication.strMainCellTotal);
        this.SecondTotalCell.setText(BaseApplication.strSecondaryCellTotal);
        this.cellNumber.setText("1");
        this.SecondCount.setText("1");
        LockControlBoardUtils.getInstances().openSerialPort();
        this.openAndClosePort.setText("关闭串口");
        ActionBar actionBar=getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(false);
            actionBar.setTitle("返回");
        }
    }

    public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
        if (paramMenuItem.getItemId() != 16908332)
            return super.onOptionsItemSelected(paramMenuItem);
        finish();
        return false;
    }

    @OnClick({R.id.quite, R.id.modifyCellTotal, R.id.openAndClosePort, R.id.openDoor, R.id.openDoorAll})
    void onclick(View paramView) {
        switch (paramView.getId()) {
            case R.id.quite:
                finish();
                break;
            case R.id.openDoorAll:
                openDoorAll();
                break;
            case R.id.openDoor:
                openDoor();
                break;
            case R.id.openAndClosePort:
                openAndClosePort();
                break;
            case R.id.modifyCellTotal:
                modifyCellTotal();
                break;
        }
    }

    private void showToast(final String msg) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
